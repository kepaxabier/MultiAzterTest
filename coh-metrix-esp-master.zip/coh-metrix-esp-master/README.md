Coh-Metrix-Esp
==============

Cálculo automatizado de métricas psicolinguísticas para el idioma español (Adaptado de Coh-Metrix 3.0)

Utiliza freeling (http://nlp.lsi.upc.edu/freeling/)

Paper:
http://www.lrec-conf.org/proceedings/lrec2016/pdf/1115_Paper.pdf
